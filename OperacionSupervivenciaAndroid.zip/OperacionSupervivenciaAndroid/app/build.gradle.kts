plugins {
    id("com.android.application")
}

android {
    namespace = "com.operacionsupervivencia.game"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.operacionsupervivencia.game"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
